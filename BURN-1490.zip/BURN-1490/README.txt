I haven't used umbraco before, so I'm not exactly sure how linking css files to the html works - I just put a link tag in the <Head/> to the css.
To get the markup to display in umbraco just pull out the content inside the <Body /> tag and paste it wherever.
That also goes for image file paths - in the css I just have the images coming from the root folder './image.png/'. 
I'm guessing all images are just stored in a centralized place in umbraco.
If you need help updating the image paths let me know.

-Jason
